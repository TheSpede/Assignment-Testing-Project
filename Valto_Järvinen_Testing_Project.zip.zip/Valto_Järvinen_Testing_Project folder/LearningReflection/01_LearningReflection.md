
# TODO

> Please use the below questions as guidelines to help you think and plan your Learning Reflection Report

## 1. How was your experience testing the given Webapp?
- It was nice. Quite straightforward to test.
     

## 2. How did you write or manage your test case? Describe the process.
- I followed the template and filled in the test cases accordingly. 
    

## 3. Do you recommend any other tools or styles for Test case management. 
 - I dont have any other ones in mind     


## 4. Which IDE (Visual Code or Atom or else) have you used to edit files?
- I used visual studio code only


     
## 5. Did you find any trouble? how did you solve the trouble?
- At first it was a bit difficult to make sense of how to write the test cases. But after watching overview lecture of it, I finally understood how to do it. 


## 6. Did you find any trouble using Github? have you used Github before? where?
- I didnt experience any trouble. I have just a few times before used github during my previous courses. 
 

      

## 7. If in the future if you need to automate these test cases, which framework or language will you use? and describe why (Robot Framework, Cypress, Selenium, or any other )
- I would probably use robot framework. Its simple enough and quite popular. And now I have gotten some experience of it



## 8. Kindly search the term `Tester` `Automation Tester` glassdoor and LinkedIn or any other job search website. Currently, list the skills and competencies that are most in-demand in software testing
- Here are some: 
At least a bachelors degree in Computer Science or related field. 
Usually some prior experience in testing
Strong knowledge of Robot Framework, Selenium or other tools
Some knowledge of coding languages like c++ or python
Basic knowledge of Git
Knowledge of bug reports, test cases, checklists and test plans





## 9. **Let's assume** that if you are going to continue with the career in Software Testing, which technical and soft skills do you need to fill up the blank in your resume?
- Firstly, to get some experience on software testing if possible and to study more about the different tools of software testing and methodology. I would probably start from there. 




## 10. Write short Learning Reflection and  Free words Do you think that project helped in putting theoretical knowledge into practice? Describe? (is there anything else that you would like to share with us concerning the current study module). e.g. regarding the quality of content and your learning (or) improvement ideas? 
- I learned basic concepts and ideas of software testing. I got the basics what testing is about and what goes into it, so its a good introduction. To me, I learned much more from doing practically than reading a lot about theoretical stuff. So if I should suggest something, then it would be adding more practical exercises after theory part for example. To make the theory more tangible. It would stick much better in the brain.




 





